package com.sanj.json;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.TextView;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

public class ViewData extends AppCompatActivity {
    private TextView txtData;
    private String userData;
    private JSONArray users;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_view);
        txtData=findViewById(R.id.txtData);

        Bundle bundle=getIntent().getExtras();
        try {
            assert bundle != null;
            users=new JSONArray(bundle.getString("data"));
            userData="";
        } catch (JSONException e) {
            e.printStackTrace();
        }
    }

    @Override
    protected void onStart() {
        super.onStart();
        try {
            txtData.setText("");
            userData="";
            for (int i = 0; i <users.length() ; i++) {
                JSONObject userObject=users.getJSONObject(i);
                userData+="\n\nUSERNAME: "+userObject.getString("username")+"\nPASSWORD: "+userObject.getString("password");
            }
            txtData.setText(userData);
        } catch (JSONException e) {
            e.printStackTrace();
        }
    }
}