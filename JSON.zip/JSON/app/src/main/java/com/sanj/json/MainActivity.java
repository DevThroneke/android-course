package com.sanj.json;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import com.google.android.material.textfield.TextInputEditText;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

public class MainActivity extends AppCompatActivity {
    private Button btnView,btnAdd;
    private TextInputEditText edUsername,edPassword;
    private JSONArray users;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        btnAdd=findViewById(R.id.btnAddData);
        btnView=findViewById(R.id.btnView);
        edPassword=findViewById(R.id.edPassword);
        edUsername=findViewById(R.id.edName);

        btnAdd.setOnClickListener(v -> addUser());
        btnView.setOnClickListener(v -> {
            Intent intent=new Intent(MainActivity.this,ViewData.class);
            intent.putExtra("data",users.toString());
            startActivity(intent);
        });

        users=new JSONArray();
    }

    private void addUser() {
        try {
            String username=edUsername.getText().toString().trim();
            String password=edPassword.getText().toString().trim();

            if (!(TextUtils.isEmpty(username)|| TextUtils.isEmpty(password))){

                JSONObject userObject=new JSONObject();
                userObject.put("username",username);
                userObject.put("password",password);

                users.put(userObject);

                edUsername.setText("");
                edPassword.setText("");

                Toast.makeText(this, "New User added", Toast.LENGTH_SHORT).show();

            }else{
                edUsername.setError("Required");
                edPassword.setError("Required");
            }
        } catch (JSONException e) {
            e.printStackTrace();
        }

    }

    @Override
    protected void onStart() {
        super.onStart();
        try {
           if(users.length()==0){
               JSONObject defaultUser=new JSONObject();
               defaultUser.put("username","Admin");
               defaultUser.put("password","1234");
               users.put(defaultUser);
           }
        } catch (JSONException e) {
            e.printStackTrace();
        }
    }
}