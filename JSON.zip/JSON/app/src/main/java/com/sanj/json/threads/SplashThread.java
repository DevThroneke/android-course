package com.sanj.json.threads;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.os.AsyncTask;
import android.widget.TextView;
import android.widget.Toast;

import com.sanj.json.MainActivity;

import static java.lang.Thread.sleep;

public class SplashThread extends AsyncTask<Void,Integer,Boolean> {

    private final TextView textView;
    private final Context mContext;
    private final Activity mActivity;
    public SplashThread(TextView textView,Context mContext,Activity mActivity) {
        this.textView=textView;
        this.mContext=mContext;
        this.mActivity=mActivity;
    }

    @Override
    protected Boolean doInBackground(Void... voids) {
        try {
            sleep(1000);
            publishProgress(1);
            sleep(1000);
            publishProgress(2);
            sleep(1000);
            publishProgress(3);
            sleep(1000);
            publishProgress(4);
            sleep(1000);
            publishProgress(5);
            sleep(1000);
            return true;
        } catch (InterruptedException e) {
            e.printStackTrace();
            return false;
        }
    }


    @Override
    protected void onPostExecute(Boolean aBoolean) {
        super.onPostExecute(aBoolean);
        if (aBoolean){
            mContext.startActivity(new Intent(mContext, MainActivity.class));
            mActivity.finish();
        }else{
            Toast.makeText(mContext, "Something Wrong Happened", Toast.LENGTH_SHORT).show();
        }
    }

    @SuppressLint("SetTextI18n")
    @Override
    protected void onProgressUpdate(Integer... values) {
        super.onProgressUpdate(values);
        switch (values[0]){
            case 1 :
                textView.setText("1");
                break;
            case 2 :
                textView.setText("2");
                break;
            case 3 :
                textView.setText("3");
                break;
            case 4 :
                textView.setText("4");
                break;
            case 5 :
                textView.setText("WELCOME YOUR MAJESTY...");
                break;
        }
    }
}
