package com.sanj.bmicalculator;

import android.os.Bundle;
import android.text.InputType;
import android.view.Gravity;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import com.google.android.material.button.MaterialButton;
import com.google.android.material.snackbar.Snackbar;

public class MainActivity extends AppCompatActivity {
    private MaterialButton btnCalculate;
    private int height,weight;
    private double BMIValue;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        btnCalculate=findViewById(R.id.btn_calculate);
        btnCalculate.setOnClickListener(v -> getWeight());
    }

    private void getWeight() {
        AlertDialog weightAlertDialog;
        AlertDialog.Builder weightBuilder=new AlertDialog.Builder(this);

        EditText edWeight=new EditText(this);
        edWeight.setInputType(InputType.TYPE_CLASS_NUMBER);
        edWeight.setMaxLines(1);
        edWeight.setTextAlignment(View.TEXT_ALIGNMENT_CENTER);
        edWeight.setGravity(Gravity.CENTER);
        edWeight.setWidth(500);
        weightBuilder.setView(edWeight);
        weightBuilder.setTitle("Please enter your weight in Kilograms(KG)");
        weightBuilder.setPositiveButton("Next", (dialog, which) -> {
            weight=Integer.parseInt(edWeight.getText().toString());
            getHeight();
        });
        weightBuilder.setNegativeButton("Cancel", (dialog, which) -> {
            Toast.makeText(MainActivity.this, "Progress cancelled", Toast.LENGTH_SHORT).show();
            dialog.dismiss();
        });
        weightAlertDialog=weightBuilder.create();
        weightAlertDialog.show();

    }

    private void getHeight() {
        AlertDialog heightAlertDialog;
        AlertDialog.Builder heightBuilder =new AlertDialog.Builder(this);

        EditText edHeight =new EditText(this);
        edHeight.setInputType(InputType.TYPE_CLASS_NUMBER);
        edHeight.setMaxLines(1);
        edHeight.setTextAlignment(View.TEXT_ALIGNMENT_CENTER);
        edHeight.setGravity(Gravity.CENTER);
        edHeight.setWidth(500);
        heightBuilder.setView(edHeight);
        heightBuilder.setTitle("Please enter your height in metres(M)");
        heightBuilder.setPositiveButton("Calculate", (dialog, which) -> {
            height=Integer.parseInt(edHeight.getText().toString());
            categorizeBMI(calculateBMI());
        });
        heightBuilder.setNegativeButton("Cancel", (dialog, which) -> {
            Toast.makeText(MainActivity.this, "Progress cancelled", Toast.LENGTH_SHORT).show();
            dialog.dismiss();
        });
        heightAlertDialog = heightBuilder.create();
        heightAlertDialog.show();

    }

    private void categorizeBMI(double BMI) {
        BMIValue=BMI;
        String BMICategory=getCategory(BMI);
        AlertDialog finalAlertDialog;
        AlertDialog.Builder finalBuilder=new AlertDialog.Builder(this);
        finalBuilder.setTitle("Body Mass Index Results");
        finalBuilder.setMessage("In accordance to the data provided earlier it discovered that you are: "+BMICategory);
        finalBuilder.setPositiveButton("Re-Calculate", (dialog, which) -> getWeight());
        finalBuilder.setNegativeButton("Finish", (dialog, which) -> {
            Snackbar.make(this,btnCalculate,"BMI Value "+BMIValue,Snackbar.LENGTH_LONG).show();
            dialog.dismiss();
        });
        finalAlertDialog = finalBuilder.create();
        finalAlertDialog.show();
    }

    private double calculateBMI() {
        double squareHeight=Math.sqrt(height);
        return weight/squareHeight;
    }

    private String getCategory(double BMI){
        if (BMI<=14){
            return "Very severely underweight";
        }else if (BMI>14 && BMI<16){
            return "Severely underweight";
        }else if (BMI>=16 && BMI<18.5){
            return "Underweight";
        }else if (BMI>=18.5 && BMI<25){
            return "Normal (healthy weight)";
        }else if (BMI>=25 && BMI<30){
            return "Overweight";
        }else if (BMI>=30 && BMI<35){
            return "Obese Class I (Moderately obese)";
        }else if (BMI>=35 && BMI<39){
            return "Obese Class II (Severely obese)";
        }else{
            return "Obese Class II (Very Severely obese)";
        }
    }

}