package com.sanj.menu;

import android.Manifest;
import android.annotation.SuppressLint;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.view.ActionMode;
import android.view.ContextMenu;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {
    private Toolbar toolbar;
    private Button btnFloatingMenu, btnContextualActionMode;
    private ActionMode actionMode;
    private final ActionMode.Callback startActionModeCallback = new ActionMode.Callback() {
        @Override
        public boolean onCreateActionMode(ActionMode mode, Menu menu) {
            getMenuInflater().inflate(R.menu.contextual_action_mode, menu);
            return true;
        }

        @Override
        public boolean onPrepareActionMode(ActionMode mode, Menu menu) {
            return false;
        }

        @SuppressLint("NonConstantResourceId")
        @Override
        public boolean onActionItemClicked(ActionMode mode, MenuItem item) {
            switch (item.getItemId()) {
                case R.id.menu_copy:
                    Toast.makeText(MainActivity.this, "Copied", Toast.LENGTH_SHORT).show();
                    break;
                case R.id.menu_delete:
                    Toast.makeText(MainActivity.this, "Deleted", Toast.LENGTH_SHORT).show();
                    break;
                case R.id.menu_share:
                    Toast.makeText(MainActivity.this, "Shared", Toast.LENGTH_SHORT).show();
                    break;
            }
            return false;
        }

        @Override
        public void onDestroyActionMode(ActionMode mode) {
            actionMode = null;
        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        toolbar = findViewById(R.id.toolbar);
        btnFloatingMenu = findViewById(R.id.btn_floating_menu);
        btnContextualActionMode = findViewById(R.id.btn_contextual_action_mode);

        registerForContextMenu(btnFloatingMenu);
        btnContextualActionMode.setOnLongClickListener(v -> {
            if (actionMode != null) {
                return false;
            }
            actionMode = startActionMode(startActionModeCallback);

            return true;
        });

        setSupportActionBar(toolbar);
    }

    //OPTION MENU
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.our_menu, menu);
        return true;
    }

    //FLOATING MENU

    @SuppressLint("NonConstantResourceId")
    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        switch (item.getItemId()) {
            case R.id.OGsettings:
                Toast.makeText(this, "OGsettings", Toast.LENGTH_SHORT).show();
                break;
            case R.id.Restart:
                Toast.makeText(this, "Restart OGWA", Toast.LENGTH_SHORT).show();
                break;
            case R.id.MessNumb:
                Toast.makeText(this, "Message Number", Toast.LENGTH_SHORT).show();
                break;
            case R.id.NewGroup:
                Toast.makeText(this, "New Group", Toast.LENGTH_SHORT).show();
                break;
            case R.id.broadcast:
                Toast.makeText(this, "New Broadcast", Toast.LENGTH_SHORT).show();
                break;
            case R.id.web:
                Toast.makeText(this, "WA web", Toast.LENGTH_SHORT).show();
                break;
            case R.id.starredMess:
                Toast.makeText(this, "Starred Messages", Toast.LENGTH_SHORT).show();
                break;
            case R.id.settings:
                Toast.makeText(this, "Settings", Toast.LENGTH_SHORT).show();
                break;
        }
        return true;
    }

    @Override
    public void onCreateContextMenu(ContextMenu menu, View v, ContextMenu.ContextMenuInfo menuInfo) {
        super.onCreateContextMenu(menu, v, menuInfo);
        menu.setHeaderTitle("Choose an option");
        getMenuInflater().inflate(R.menu.floating_menu, menu);
    }

    @SuppressLint("NonConstantResourceId")
    @Override
    public boolean onContextItemSelected(@NonNull MenuItem item) {
        switch (item.getItemId()) {
            case R.id.menu_option_1:
                Toast.makeText(this, "Option 1 Selected", Toast.LENGTH_SHORT).show();
                break;
            case R.id.menu_option_2:
                Toast.makeText(this, "Option 2 Selected", Toast.LENGTH_SHORT).show();
                break;
        }
        return super.onContextItemSelected(item);
    }

    //permission
    private void askPermission() {
        int fineLocation = ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION);
        int courseLocation = ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_COARSE_LOCATION);
        int netState = ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_NETWORK_STATE);
        int writeContact = ContextCompat.checkSelfPermission(this, Manifest.permission.WRITE_CONTACTS);
        int camera = ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA);
        int callPhone = ContextCompat.checkSelfPermission(this, Manifest.permission.CALL_PHONE);

        List<String> listPermissionsNeeded = new ArrayList<>();

        if (fineLocation != PackageManager.PERMISSION_GRANTED) {
            listPermissionsNeeded.add(Manifest.permission.ACCESS_FINE_LOCATION);
        }
        if (courseLocation != PackageManager.PERMISSION_GRANTED) {
            listPermissionsNeeded.add(Manifest.permission.ACCESS_COARSE_LOCATION);
        }
        if (netState != PackageManager.PERMISSION_GRANTED) {
            listPermissionsNeeded.add(Manifest.permission.ACCESS_NETWORK_STATE);
        }
        if (writeContact != PackageManager.PERMISSION_GRANTED) {
            listPermissionsNeeded.add(Manifest.permission.WRITE_CONTACTS);
        }
        if (camera != PackageManager.PERMISSION_GRANTED) {
            listPermissionsNeeded.add(Manifest.permission.CAMERA);
        }
        if (callPhone != PackageManager.PERMISSION_GRANTED) {
            listPermissionsNeeded.add(Manifest.permission.CALL_PHONE);
        }
        if (!listPermissionsNeeded.isEmpty()) {
            int REQUEST_ID_MULTIPLE_PERMISSIONS = 100;
            ActivityCompat.requestPermissions(this, listPermissionsNeeded.toArray(new String[listPermissionsNeeded.size()]), REQUEST_ID_MULTIPLE_PERMISSIONS);
        }
    }

    @Override
    protected void onStart() {
        super.onStart();
        askPermission();
    }
}