package com.sanj.tiktimer.threads;

public class ThreadConstants {
    public static boolean isTaskRunning;
    public static boolean isApplicationOpen;

}
