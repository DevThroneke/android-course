package com.sanj.lesson2.activities;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

import com.sanj.lesson2.R;

public class Try1 extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_try1);
    }
}