package com.sanj.lesson2.model;

import java.io.Serializable;
import java.util.List;

public class UserModel implements Serializable {
    private final String name,email,phone,password,gender,levelOfProgrammer;
    private final List<String>languages;

    public UserModel(String name, String email, String phone, String password, String gender, String levelOfProgrammer, List<String> languages) {
        this.name = name;
        this.email = email;
        this.phone = phone;
        this.password = password;
        this.gender = gender;
        this.levelOfProgrammer = levelOfProgrammer;
        this.languages = languages;
    }

    public String getName() {
        return name;
    }


    public String getEmail() {
        return email;
    }

    public String getPhone() {
        return phone;
    }

    public String getPassword() {
        return password;
    }

    public String getGender() {
        return gender;
    }

    public String getLevelOfProgrammer() {
        return levelOfProgrammer;
    }

    public List<String> getLanguages() {
        return languages;
    }

}
