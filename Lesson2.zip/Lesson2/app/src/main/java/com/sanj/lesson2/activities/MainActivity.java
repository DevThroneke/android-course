package com.sanj.lesson2.activities;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.material.textfield.TextInputEditText;
import com.sanj.lesson2.R;
import com.sanj.lesson2.model.UserModel;

import java.util.Objects;

public class MainActivity extends AppCompatActivity implements View.OnClickListener {
    private UserModel userModel=null;
    private TextInputEditText edEmail,edPassword;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Button btnLogin = findViewById(R.id.btn_login);
        TextView toCreateAccount = findViewById(R.id.toCreateAccount);
        edEmail=findViewById(R.id.edEmail);
        edPassword=findViewById(R.id.edPassword);

        btnLogin.setOnClickListener(this);
        toCreateAccount.setOnClickListener(this);

        Bundle dataBundle=getIntent().getExtras();
        if (dataBundle!=null){
            userModel= (UserModel) dataBundle.getSerializable("data");
        }
    }

    @SuppressLint("NonConstantResourceId")
    @Override
    public void onClick(View v) {
        switch(v.getId()){
            case R.id.btn_login:
                authenticate();
                break;
            case R.id.toCreateAccount:
                startActivity(new Intent(MainActivity.this,CreateAccount.class));
                finish();
                break;

        }
    }

    private void authenticate() {
        String email,password;
        email= Objects.requireNonNull(edEmail.getText()).toString().trim();
        password= Objects.requireNonNull(edPassword.getText()).toString().trim();

        if (userModel!=null){
            if (!(TextUtils.isEmpty(email) || TextUtils.isEmpty(password))){
                String dbEmail=userModel.getEmail();
                String dbPassword=userModel.getPassword();

                if (dbEmail.equals(email) && dbPassword.equals(password)){
                    edEmail.setText("");
                    edPassword.setText("");
                    Intent intent=new Intent(this,Home.class);
                    intent.putExtra("data", userModel);
                    startActivity(intent);
                    Toast.makeText(this,"Login Successful",Toast.LENGTH_LONG).show();
                }else{
                    Toast.makeText(this,"Invalid login credential",Toast.LENGTH_LONG).show();
                }
            }else{
                Toast.makeText(this,"All fields Required",Toast.LENGTH_LONG).show();
            }
        }else{
            Toast.makeText(this,"Create account then Login",Toast.LENGTH_LONG).show();
        }
    }
}