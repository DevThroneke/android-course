package com.sanj.lesson2.activities;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.view.View;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.material.appbar.CollapsingToolbarLayout;
import com.sanj.lesson2.R;
import com.sanj.lesson2.model.UserModel;

import java.util.Objects;

public class Home extends AppCompatActivity implements View.OnClickListener {
    private TextView txtEmail,txtPhone,txtGender,txtLevel,txtLanguage;
    private CollapsingToolbarLayout mCollapsingToolbar;
    private ImageView mImageView;

    private UserModel userModel=null;
    private boolean backPressed=false;

    @SuppressLint("UseCompatLoadingForDrawables")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home);
        ImageButton btnEdit = findViewById(R.id.btnEdit);
        txtEmail=findViewById(R.id.txtEmail);
        txtPhone=findViewById(R.id.txtPhone);
        txtGender=findViewById(R.id.txtGender);
        txtLevel=findViewById(R.id.txtLevel);
        txtLanguage=findViewById(R.id.txtLanguage);
        mImageView=findViewById(R.id.image);
        mImageView.setImageResource(R.mipmap.dev_logo);

        mCollapsingToolbar = findViewById(R.id.collapsing_toolbar);
        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        Objects.requireNonNull(getSupportActionBar()).setDisplayHomeAsUpEnabled(true);
        toolbar.setNavigationOnClickListener(view -> onBackPressed());

        txtPhone.setOnClickListener(this);
        btnEdit.setOnClickListener(this);

        Bundle dataBundle=getIntent().getExtras();
        if (dataBundle!=null){
            userModel= (UserModel) dataBundle.getSerializable("data");
        }
    }

    @SuppressLint("NonConstantResourceId")
    @Override
    public void onClick(View v) {
        switch (v.getId()){
            case R.id.txtPhone:
                makeCall();
                break;
            case R.id.btnEdit:
                toEdit();
                break;
        }
    }

    private void makeCall(){
        if (userModel!=null){
            Intent intent = new Intent(Intent.ACTION_DIAL);
            intent.setData(Uri.parse("tel:"+userModel.getPhone()));
            startActivity(intent);
        }
    }
    private void toEdit(){
        if (userModel!=null){
            Intent intent=new Intent(this,EditUser.class);
            intent.putExtra("data", userModel);
            startActivity(intent);
            finish();
        }
    }
    private void populateViews(){
        if (userModel!=null){
            txtPhone.setText(userModel.getPhone());
            txtLevel.setText(userModel.getLevelOfProgrammer());
            txtGender.setText(userModel.getGender());
            txtEmail.setText(userModel.getEmail());
            mCollapsingToolbar.setTitle(userModel.getName());

            StringBuilder languages=new StringBuilder();
            for (String language:userModel.getLanguages()){
                languages.append(language).append(", ");
            }
            txtLanguage.setText(languages.toString());
        }
    }
    @Override
    protected void onStart() {
        super.onStart();
        populateViews();
    }

    @Override
    public void onBackPressed() {
        if (backPressed) {
            super.onBackPressed();
        } else {
            backPressed = true;
            Toast.makeText(this, "Tap again to exit", Toast.LENGTH_LONG).show();
            new Handler().postDelayed(() -> backPressed = false, 3000);
        }
    }
}