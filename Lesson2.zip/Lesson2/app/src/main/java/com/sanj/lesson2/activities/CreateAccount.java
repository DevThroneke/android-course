package com.sanj.lesson2.activities;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.CheckBox;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Spinner;
import android.widget.Toast;

import com.google.android.material.textfield.TextInputEditText;
import com.sanj.lesson2.R;
import com.sanj.lesson2.model.UserModel;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

public class CreateAccount extends AppCompatActivity implements View.OnClickListener {
    private TextInputEditText edName,edEmail,edPhone,edPassword,edConfirmPassword;
    private RadioGroup rgGender;
    private CheckBox cbJava,cbC,cbKotlin,cbPython;

    private List<String> languages;
    private String levelOfProgrammer;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_create_account);

        Toolbar toolbar = findViewById(R.id.toolbar);
        edConfirmPassword=findViewById(R.id.edConfirmPassword);
        edEmail=findViewById(R.id.edEmail);
        edName=findViewById(R.id.edName);
        edPassword=findViewById(R.id.edPassword);
        edPhone=findViewById(R.id.edPhone);
        rgGender=findViewById(R.id.rgGender);
        RadioButton activeRadio = findViewById(R.id.rbMale);
        cbC=findViewById(R.id.cbC);
        cbJava=findViewById(R.id.cbJava);
        cbKotlin=findViewById(R.id.cbKotlin);
        cbPython=findViewById(R.id.cbPython);
        Spinner spinnerLevel = findViewById(R.id.spinnerLevel);

        setSupportActionBar(toolbar);
        toolbar.setNavigationIcon(R.drawable.ic_arrow_back);
        toolbar.setNavigationOnClickListener(view -> onBackPressed());

        activeRadio.setChecked(true);
        languages=new ArrayList<>();

        cbC.setOnClickListener(this);
        cbPython.setOnClickListener(this);
        cbKotlin.setOnClickListener(this);
        cbJava.setOnClickListener(this);

        String[] spinnerOptions=new String[]{"Beginner","Amateur","Intermediate","Advanced"};
        ArrayAdapter<String> spinnerAdapter= new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, spinnerOptions);
        spinnerLevel.setAdapter(spinnerAdapter);
        spinnerLevel.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                levelOfProgrammer=spinnerOptions[position];
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {
                levelOfProgrammer=spinnerOptions[0];
            }
        });

    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.create_account_menu, menu);
        return true;
    }

    @SuppressLint("NonConstantResourceId")
    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        if (item.getItemId() == R.id.menu_save) {
            create_account();
        }
        return true;
    }

    private void create_account() {
        String name,email,phone,password,gender,confirmPassword;
        name= Objects.requireNonNull(edName.getText()).toString().trim();
        email= Objects.requireNonNull(edEmail.getText()).toString().trim();
        phone= Objects.requireNonNull(edPhone.getText()).toString().trim();
        password= Objects.requireNonNull(edPassword.getText()).toString().trim();
        confirmPassword= Objects.requireNonNull(edConfirmPassword.getText()).toString().trim();

        if (!(TextUtils.isEmpty(name) || TextUtils.isEmpty(email) || TextUtils.isEmpty(phone) ||
                TextUtils.isEmpty(password) || TextUtils.isEmpty(confirmPassword) || languages.isEmpty())){
            if (password.equals(confirmPassword)){
                int selectedGender=rgGender.getCheckedRadioButtonId();
                RadioButton radioButtonGender=findViewById(selectedGender);
                gender=radioButtonGender.getText().toString();

                UserModel userModel=new UserModel(name,email,phone,password,gender,levelOfProgrammer,languages);

                Intent intent=new Intent(this,MainActivity.class);
                intent.putExtra("data", userModel);
                startActivity(intent);
                finish();
                Toast.makeText(this,"Registration Successful. Login using your details",Toast.LENGTH_LONG).show();

            }else{
                Toast.makeText(this,"Provided different passwords",Toast.LENGTH_LONG).show();
            }
        }else{
            Toast.makeText(this,"All fields Required",Toast.LENGTH_LONG).show();
        }

    }

    @SuppressLint("NonConstantResourceId")
    @Override
    public void onClick(View v) {
        switch (v.getId()){
            case R.id.cbC:
                updateLanguagesList("C++",cbC);
                break;
            case R.id.cbKotlin:
                updateLanguagesList("Kotlin",cbKotlin);
                break;
            case R.id.cbJava:
                updateLanguagesList("Java",cbJava);
                break;
            case R.id.cbPython:
                updateLanguagesList("Python",cbPython);
                break;
        }
    }
    private void updateLanguagesList(String language,CheckBox checkBox){
        if (checkBox.isChecked()){
            languages.add(language);
        }else{
            languages.remove(language);
        }
    }

    @Override
    public void onBackPressed() {
        startActivity(new Intent(this,MainActivity.class));
        super.onBackPressed();

    }
}