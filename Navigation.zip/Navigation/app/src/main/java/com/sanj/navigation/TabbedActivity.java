package com.sanj.navigation;

import androidx.appcompat.app.AppCompatActivity;
import androidx.viewpager.widget.ViewPager;

import android.os.Bundle;

import com.google.android.material.tabs.TabLayout;

public class TabbedActivity extends AppCompatActivity {
    TabLayout tabLayout;
    ViewPager viewpager;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_tabbed);
        tabLayout = findViewById(R.id.tabLayout);
        viewpager = findViewById(R.id.vPager);

        ViewPagerAdapter adapter = new ViewPagerAdapter(getSupportFragmentManager());
        adapter.addFragment(new HomeFragment(), "Home");
        adapter.addFragment(new AccountFragment(), "Account");
        adapter.addFragment(new NotificationFragment(), "Notification");
        adapter.addFragment(new OptionsFragment(), "Options");

        viewpager.setAdapter(adapter);
        tabLayout.setupWithViewPager(viewpager);
    }

}